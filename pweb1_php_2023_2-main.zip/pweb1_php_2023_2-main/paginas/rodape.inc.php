<div class="fixed-bottom navbar-dark bg-dark" style="color: #fff; padding: 0 16px;">
    <footer class="py-3 my-4">
        <ul class="nav justify-content-center border-bottom pb-3 mb-3">
            <li class="nav-item"><a href="/index.php" class="nav-link" style="color: rgba(255,255,255,.7);">Sair</a>
            </li>
        </ul>
        <p class="text-center text-body-secondary">© Mitsubishi</p>
    </footer>
</div>

