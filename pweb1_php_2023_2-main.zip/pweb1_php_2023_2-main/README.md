# pweb1_php_2023_2
Projeto desenvolvido durante as aulas de programação web 1 com PHP 2023.2

## Comandos básicos Git

**Clonar projeto**  
`git clone URL_PROJETO`

**Adicionar todos arquivos para serem versionados**  
`git add .`

**Commitar o arquivo para ser versionados**  
`git commit -m "Sua mensagem"`

**Enviar as alterações para o repositorio remoto do Git**  
`git push`

**Atualizar arquivos do projeto local de acordo com o repositorio do Git remoto**  
`git pull`
